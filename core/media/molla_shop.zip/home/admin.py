from django.contrib import admin
from .models import TagNav,TagNewPage,TagFooter,SiteSetting,NavOne,NavTwo,NavThree,Slider,ZirSlider,Tabligh,FooterAsli,FooterZir,City,State

# Register your models here.

admin.site.register(TagNav)
admin.site.register(TagNewPage)
admin.site.register(TagFooter)
admin.site.register(SiteSetting)
admin.site.register(NavOne)
admin.site.register(NavTwo)
admin.site.register(NavThree)
admin.site.register(Slider)
admin.site.register(ZirSlider)
admin.site.register(Tabligh)
admin.site.register(FooterAsli)
admin.site.register(FooterZir)

class StateAdmin(admin.ModelAdmin):
    list_display = ['name','price']
    list_editable = ['price',]

admin.site.register(City)
admin.site.register(State,StateAdmin)

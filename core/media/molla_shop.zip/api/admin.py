from django.contrib import admin

# Register your models here.
from .models import CommentEx


admin.site.register(CommentEx)
from django.shortcuts import render
from rest_framework import generics
from account.models import MyUser
from .serializers import UserSerializer,CommentSerializer
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAdminUser,AllowAny
from .models import CommentEx
# Create your views here.

class UserList(generics.ListAPIView):
    queryset = MyUser.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAdminUser,]


class CommentEx(generics.ListCreateAPIView):
    queryset = CommentEx.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [IsAdminUser,]
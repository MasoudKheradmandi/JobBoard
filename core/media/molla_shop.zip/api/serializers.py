from dataclasses import fields
from rest_framework import serializers
from account.models import MyUser
from .models import CommentEx


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = MyUser
        exclude = ['token','password','groups','user_permissions']

# class CommentSerializer(serializers.Serializer):
#     name = serializers.CharField(max_length=100)
#     body = serializers.CharField(max_length=100)
#     number = serializers.IntegerField()

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = CommentEx
        fields = "__all__"
from django.urls import path

from . import views

urlpatterns = [
    path('userlist/',views.UserList.as_view(),name='userlist'),
    path('comment/',views.CommentEx.as_view(),name='Comment'),
]

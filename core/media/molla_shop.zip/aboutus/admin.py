from django.contrib import admin
from .models import Company,First,Team,Three
# Register your models here.

admin.site.register(Company)

admin.site.register(First)
admin.site.register(Team)
admin.site.register(Three)

from django.contrib import admin
from .models import KhabarName , OurShop,ContactDetail , ContactUs
# Register your models here.
admin.site.register(KhabarName)
admin.site.register(OurShop)
admin.site.register(ContactDetail)
admin.site.register(ContactUs)

